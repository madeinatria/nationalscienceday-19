<nav style="  font-weight: 250; color:white!important; font-family: 'Raleway', sans-serif; min-height:55px !important; font-size: 13.5px;" class="navbar navbar-expand-lg navbar-dark bg-dark">
   <a class="navbar-brand" href="#">National Science Day'19</a>
   <button  class="navbar-toggler ml-auto custom-toggler"  type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
   <span class="navbar-toggler-icon"></span>
   </button>
   <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
         <li class="nav-item px-2">
            <a style="    font-weight: 500; color:white!important;" class="nav-link" href="index.php">HOME</a>
         </li>
        
         <li class="nav-item px-2">
            <a  style="  font-weight: 500; color:white;" class="nav-link" href="events.php">EVENTS</a>
         </li>
       
      </ul>
   </div>
</nav>